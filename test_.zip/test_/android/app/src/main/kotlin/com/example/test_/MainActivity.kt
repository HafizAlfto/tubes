package com.example.test_

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
