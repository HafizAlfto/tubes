import 'package:intl/intl.dart';

final numberFormat =
    NumberFormat.currency(locale: 'id-ID', symbol: 'Rp', decimalDigits: 0);
